
export const USE_API = true;
export const API_BASE = ""; // same origin
